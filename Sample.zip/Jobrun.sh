#-------------------------------------------------
#Script Name   :Jobrun.sh
#Created By    :Venkata Ramana S
#Creation Date :17th November 2016
#Modified By   : --
#Lastupdatedate: --
#------------------------------------------------

function status()
{
if [ "$rc" == 0 ];then 
echo "Script sucessfully started  workflow">>$logpath
exit 0
else
echo "Failed to start  workflow RC is $rc !!!">>$logpath
exit 1
fi
}

. ~/.profile

log=/opt/Informatica/infa_shared/scripts/FLECS_11_RPTDM_00
logpath=$log/Jobrunlog_"$1".txt

#param
 
echo "--------------------------------">$logpath
echo "Script started at `date`" >$logpath

echo "">>$logpath
echo "---Environmental Variables---">>$logpath
echo "Domain Name: $PMDomainName">>$logpath
echo "Integration Service Name : $PMIntegrationService">>$logpath
echo "Infa Shared Path : $INFA_SHARED">>$logpath
echo "Workflowname:$1">>$logpath
echo "-----------------------------">>$logpath
echo "">>$logpath

Domain=$PMDomainName
IS=$PMIntegrationService
Folder='FLECS_11_RPTDM_00'
Wfname=$1

echo "/opt/Informatica/PowerCenter9.6.1/server/bin/pmcmd startworkflow -sv $IS -d $Domain -uv USERCLFLECSRPTDMNAME -pv USERCLFLECSRPTDMPASS -f $Folder $Wfname">>$logpath

echo "PMCMD started at `date`">>$logpath
#/opt/Informatica/PowerCenter9.6.1/server/bin/
sleep 5
pmcmd startworkflow -sv $IS -d $Domain -uv USERCLFLECSRPTDMNAME -pv USERCLFLECSRPTDMPASS -f $Folder $Wfname  >>$logpath
rc=$?
status $rc

#chmod 777 /opt/Informatica/infa_shared/scripts/FLECS_11_RPTDM_00/Jobrunlog.txt

