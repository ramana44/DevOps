
log=/opt/Informatica/infa_shared/scripts/FLECS_11_RPTDM_00/mergelog.txt

Param=/opt/Informatica/infa_shared/parmfile/FLECS_11_RPTDM_00
TGT=/opt/Informatica/infa_shared/parmfile/FLECS_11_RPTDM_00/FLECSRPTDM.parm
cat $Param/$1 >> $TGT

echo "$?">>$log
